from models.albums import Albums
from models.repos.a_albums import AAlbum
import sqlite3

class AlbumRepo(AAlbum):
    def create_albums(self, models: Albums) -> None:
        try:
            with sqlite3.connect("chinook.db") as conn:
                cursor = conn.cursor()
                cursor.execute('INSERT INTO Albums (title, artistid) VALUES(?, ?)',(models.title, models.artistid))
                conn.commit()
        except sqlite3.Error as e:
            print(f"Database error: {e}")
        return None

    def update_albums(self, al_id: int, models: Albums) -> None:
        try:
            with sqlite3.connect("chinook.db") as conn:
                cursor = conn.cursor()
                cursor.execute('UPDATE Albums SET title=?, artistid=? WHERE AlbumId=?', (models.title, models.artistid, al_id))
                conn.commit()
        except sqlite3.Error as e:
            print(f"Database error: {e}")
        return None

    def delete_albums(self, al_id: int) -> None:
        try:
            with sqlite3.connect("chinook.db") as conn:
                cursor = conn.cursor()
                cursor.execute('DELETE FROM Albums WHERE AlbumId=?', (al_id,))
                conn.commit()
        except sqlite3.Error as e:
            print(f"Database error: {e}")
        return None


    def get_albums(self, al_id: int) -> Albums:
        try:
            with sqlite3.connect("chinook.db") as conn:
                cursor=conn.execute('SELECT * FROM Albums WHERE AlbumId=?', (al_id,))
                row=cursor.fetchone()
                if row:
                    return Albums (albumid=row[0], title=row[1], artistid=row[2])
                else:
                    return None
        except sqlite3.Error as e:
            print(f"Database error: {e}")
        return None


    def get_all_albums(self) -> list[Albums]:
        data_list = []
        try:
            with sqlite3.connect("chinook.db") as conn:
                cursor = conn.execute("SELECT * FROM albums")
                for row in cursor:
                    al = Albums(albumid=row[0], title=row[1],artistid=row[0])
                    data_list.append(al)
        except sqlite3.Error as e:
            print(f"Database error: {e}")
        return data_list