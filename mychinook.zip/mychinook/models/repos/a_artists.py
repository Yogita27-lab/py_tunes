from abc import ABC, abstractmethod
from models.artists import Artist

class AArtist(ABC):
    @abstractmethod
    def create_artists(self, model: Artist) -> None:
        pass

    @abstractmethod
    def update_artists(self, at_id: int, model: Artist) -> None:
        pass

    @abstractmethod 
    def delete_artists(self, at_id: int) -> None:
        pass

    @abstractmethod
    def get_artists(self, at_id: int) -> Artist:
        pass
 
    @abstractmethod
    def get_all_artists(self) -> list[Artist]:
        pass