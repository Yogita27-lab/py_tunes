from abc import ABC, abstractmethod
from models.albums import Albums

class AAlbum(ABC):
    @abstractmethod
    def create_albums(self, model: Albums) -> None:
        pass

    @abstractmethod
    def update_albums(self, al_id: int, model: Albums) -> None:
        pass

    @abstractmethod 
    def delete_albums(self, al_id: int) -> None:
        pass

    @abstractmethod
    def get_albums(self, al_id: int) -> Albums:
        pass
 
    @abstractmethod
    def get_all_albums(self) -> list[Albums]:
        pass