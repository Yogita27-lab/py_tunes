from models.genres import Genres
from models.repos.a_genres import AGenres
import sqlite3

class GenresRepo(AGenres):
    def create_genres(self, models:Genres) -> None:
        try:
            with sqlite3.connect("chinook.db") as conn:
                cursor = conn.cursor()
                cursor = conn.execute('INSERT INTO albums (GenrerId , Name) VALUES(?, ?)' ,(models.genreid, models.name))
                conn.commit()
        except sqlite3.Error as e:
            print(f"Database error: {e}")
        return None
        

    def update_genres(self, gn_id: int, models: Genres) -> None:
        try:
            with sqlite3.connect("chinook.db") as conn:
                cursor = conn.cursor()
                cursor = conn.execute('UPDATE albums SET Name=? ,  WHERE GenreId=?' , (models.name , models.genreid , gn_id ))
                conn.commit()
        except sqlite3.Error as e:
            print(f"Database error: {e}")
        return None
       

    def delete_genres(self, gn_id: int) -> None:
        try:
            with sqlite3.connect("chinook.db") as conn:
                cursor = conn.cursor()
                cursor = conn.execute('DELETE FROM genres WHERE GenreId=?',(gn_id,))
                conn.commit()
        except sqlite3.Error as e:
            print(f"Database error: {e}")
        return None
        
       

    def get_genres(self, gn_id: int) -> Genres:
        try:
            with sqlite3.connect("chinook.db") as conn:
                cursor = conn.execute('SELECT* FROM Genres WHERE GenreId=?',(gn_id))
                row=conn.fetchone()
                if row:
                    return Genres (genreid=row[0],name=row[1])
                else:
                    return None
        except sqlite3.Error as e:
            print(f"Database error: {e}")
        return None
       
    def get_all_genres(self) -> list[Genres]:
        data_list = []
        try:
            with sqlite3.connect("chinook.db") as conn:
                cursor = conn.execute("SELECT * FROM genres")
                for row in cursor:
                    gn = Genres(genreid=row[0], name=row[1])
                    data_list.append(gn)
        except sqlite3.Error as e:
            print(f"Database error: {e}")
        return data_list