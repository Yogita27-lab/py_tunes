from models.media_type import MediaType
from models.repos.a_media_type import AMediaType
import sqlite3

class MediaTypeRepos(AMediaType):
    def create_media_type(self, models: MediaType) -> None:
        try:
            with sqlite3.connect("chinook.db") as conn:
                cursor = conn.cursor()
                cursor.execute('INSERT INTO media_types (name, mediatypeid) VALUES(?, ?)',(models.name, models.mediatypeid),)
                conn.commit()
        except sqlite3.Error as e:
            print(f"Database error: {e}")
        return None
        


    def update_media_type(self, mt_id: int, models: MediaType) -> None:
        try:
            with sqlite3.connect("chinook.db") as conn:
                cursor = conn.cursor()
                cursor.execute('UPDATE media_types SET name=? WHERE mediatypeid=?', (models.name,mt_id))
                conn.commit()
        except sqlite3.Error as e:
            print(f"Database error: {e}")
        return None
        

    def delete_media_type(self, mt_id: int) -> None:
        try:
            with sqlite3.connect("chinook.db") as conn:
                cursor = conn.cursor()
                cursor.execute('DELETE FROM media_types WHERE mediatypeid=?', (mt_id,))
                conn.commit()
        except sqlite3.Error as e:
            print(f"Database error: {e}")
        return None
        

    def get_media_type(self, mt_id: int) -> MediaType:
        try:
            with sqlite3.connect("chinook.db") as conn:
                cursor=conn.execute('SELECT * FROM media_types WHERE mediatypeid=?', (mt_id,))
                row=cursor.fetchone()
                if row:
                    return MediaType (mediatypeid=row[0], name=row[1])
                else:
                    return None
        except sqlite3.Error as e:
            print(f"Database error: {e}")
        return None


    def get_all_media_types(self) -> list[MediaType]:
        data_list = []
        try:
            with sqlite3.connect("chinook.db") as conn:
                cursor = conn.execute("SELECT * FROM media_types")
                for row in cursor:
                    mt = MediaType(mediatypeid=row[0], name=row[1])
                    data_list.append(mt)
        except sqlite3.Error as e:
            print(f"Database error: {e}")
        return data_list