import sqlite3
from models.customers import Customers
from models.repos.a_customers import ACustomers


class CustomersRepo(ACustomers):

    def add_customers(self, models: Customers) -> None:
        try:
            with sqlite3.connect("chinook.db") as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT INTO customers (
                        customerid, firstname, lastname, company,
                        address, city, state, country,
                        postalcode, phone, fax, email, supportrepid
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    models.customerid,
                    models.firstname,
                    models.lastname,
                    models.company,
                    models.address,
                    models.city,
                    models.state,
                    models.country,
                    models.postalcode,
                    models.phone,
                    models.fax,
                    models.email,
                    models.supportrepid
                ))
                conn.commit()
                print("Customer added successfully!")
        except sqlite3.Error as e:
            print(f"Database error: {e}")

    def update_customers(self, cu_id: int, models: Customers) -> None:
        try:
            with sqlite3.connect("chinook.db") as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    UPDATE customers
                    SET firstname = ?, 
                         lastname = ?,
                         company = ?, 
                         address = ?,
                          city = ?, 
                         state = ?, 
                         country = ?, 
                        postalcode = ?,
                        phone = ?,
                         fax = ?,
                         email = ?,
                         supportrepid = ?
                    WHERE customerid = ?
                """, (
                    
                    models.firstname,
                    models.lastname,
                    models.company,
                    models.address,
                    models.city,
                    models.state,
                    models.country,
                    models.postalcode,
                    models.phone,
                    models.fax,
                    models.email,
                    models.supportrepid,
                    cu_id
                
                    
                ))
                conn.commit()
                print("Customer updated successfully!")
        except sqlite3.Error as e:
            print(f"Database error: {e}")

    def delete_customers(self, cu_id: int) -> None:
        try:
            with sqlite3.connect("chinook.db") as conn:
                cursor = conn.cursor()
                cursor.execute("DELETE FROM customers WHERE customerid = ?", (cu_id,))
                conn.commit()
                print("Customer deleted successfully!")
        except sqlite3.Error as e:
            print(f"Database error: {e}")

    def get_customers(self, cu_id: int) -> Customers:
        try:
            with sqlite3.connect("chinook.db") as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT * FROM customers WHERE customerid = ?", (cu_id,))
                row = cursor.fetchone()
                if row:
                    return Customers(
                        customerid=row[0],
                        firstname=row[1],
                        lastname=row[2],
                        company=row[3],
                        address=row[4],
                        city=row[5],
                        state=row[6],
                        country=row[7],
                        postalcode=row[8],
                        phone=row[9],
                        fax=row[10],
                        email=row[11],
                        supportrepid=row[12]
                    )
                return None
        except sqlite3.Error as e:
            print(f"Database error: {e}")
            return None

    def get_all_customers(self) -> list[Customers]:
        data_list = []
        try:
            with sqlite3.connect("chinook.db") as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT * FROM customers")
                rows = cursor.fetchall()
                for row in rows:
                    cu = Customers(
                        customerid=row[0],
                        firstname=row[1],
                        lastname=row[2],
                        company=row[3],
                        address=row[4],
                        city=row[5],
                        state=row[6],
                        country=row[7],
                        postalcode=row[8],
                        phone=row[9],
                        fax=row[10],
                        email=row[11],
                        supportrepid=row[12]
                    )
                    data_list.append(cu)
        except sqlite3.Error as e:
            print(f"Database error: {e}")
        return data_list
