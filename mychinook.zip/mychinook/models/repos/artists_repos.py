from models.artists import Artist
from models.repos.a_artists import AArtist
import sqlite3

class ArtistRepo(AArtist):
    def create_artists(self, models: Artist) -> None:
        try:
            with sqlite3.connect("chinook.db") as conn:
                cursor = conn.cursor()
                cursor.execute('INSERT INTO artists (name, artistid) VALUES(?, ?)',(models.name, models.artistid),)
                conn.commit()
        except sqlite3.Error as e:
            print(f"Database error: {e}")
        return None

    def update_artists(self, at_id: int, models: Artist) -> None:
        try:
            with sqlite3.connect("chinook.db") as conn:
                cursor = conn.cursor()
                cursor.execute('UPDATE artists SET name=? WHERE artistid=?', (models.name,at_id))
                conn.commit()
        except sqlite3.Error as e:
            print(f"Database error: {e}")
        return None
        

    def delete_artists(self, at_id: int) -> None:
        try:
            with sqlite3.connect("chinook.db") as conn:
                cursor = conn.cursor()
                cursor.execute('DELETE FROM artists WHERE artistid=?', (at_id,))
                conn.commit()
        except sqlite3.Error as e:
            print(f"Database error: {e}")
        return None
        


    def get_artists(self, at_id: int) -> Artist:
        try:
            with sqlite3.connect("chinook.db") as conn:
                cursor=conn.execute('SELECT * FROM artists WHERE artistsid=?', (at_id,))
                row=cursor.fetchone()
                if row:
                    return Artist (artistid=row[0], name=row[1])
                else:
                    return None
        except sqlite3.Error as e:
            print(f"Database error: {e}")
        return None

    def get_all_artists(self) -> list[Artist]:
        data_list = []
        try:
            with sqlite3.connect("chinook.db") as conn:
                cursor = conn.execute("SELECT * FROM artists")
                for row in cursor:
                    at = Artist(artistid=row[0], name=row[1])
                    data_list.append(at)
        except sqlite3.Error as e:
            print(f"Database error: {e}")
        return data_list
    
    def get_artist_with_albums(self) -> list[tuple[str,str]]:
        data_list = []
        try:
            with sqlite3.connect("chinook.db") as conn:
                cursor = conn.cursor()
                query="""
                SELECT artists.Name, albums.Title
                FROM artists
                JOIN albums ON artists.ArtistId = albums.ArtistId;
                 """
                cursor.execute(query)
                rows=cursor.fetchall()

                for row in rows:
                    artist_name =row[0]
                    album_title =row[1]
                    data_list.append((artist_name,album_title))
        except sqlite3.Error as e:
            print(f"Database error: {e}")
        return data_list