from abc import ABC, abstractmethod
from models.customers import Customers

class ACustomers(ABC):
    @abstractmethod
    def add_customers(self, model:Customers) -> None:
        pass

    @abstractmethod
    def update_customers(self, cu_id: int, model: Customers) -> None:
        pass

    @abstractmethod 
    def delete_customers(self, cu_id: int) -> None:
        pass

    @abstractmethod
    def get_customers(self, cu_id: int) -> Customers:
        pass
 
    @abstractmethod
    def get_all_customers(self) -> list[Customers]:
        pass