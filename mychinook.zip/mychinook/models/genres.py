class Genres:
    def _init_(self, name: str, genreid:int = None):
        self.genreid = genreid
        self.name = name

    def _repr_(self):
        return f"genre(id={self.genreid}, name={self.name})"