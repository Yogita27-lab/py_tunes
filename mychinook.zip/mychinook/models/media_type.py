class MediaType:
    def __init__(self, name: str,mediatypeid:int= None):
        self.mediatypeid = mediatypeid
        self.name = name

    def __repr__(self):
        return f"MediaType(id={self.mediatypeid}, name={self.name})"