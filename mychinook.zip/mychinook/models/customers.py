class Customers:
    def __init__(
        self,
        
        firstname: str,
        lastname: str,
        company: str = None,
        address: str = None,
        city: str = None,
        state: str = None,
        country: str = None,
        postalcode: str = None,
        phone: str = None,
        fax: str = None,
        email: str = None,
        supportrepid: int = None,
        customerid: int=None
    ):
        self.customerid = customerid
        self.firstname = firstname
        self.lastname = lastname
        self.company = company
        self.address = address
        self.city = city
        self.state = state
        self.country = country
        self.postalcode = postalcode
        self.phone = phone
        self.fax = fax
        self.email = email
        self.supportrepid = supportrepid

    def __repr__(self):
        return (
            f"Customers(customerid={self.customerid}, firstname='{self.firstname}', "
            f"lastname='{self.lastname}', company='{self.company}', address='{self.address}', "
            f"city='{self.city}', state='{self.state}', country='{self.country}', "
            f"postalcode='{self.postalcode}', phone='{self.phone}', fax='{self.fax}', "
            f"email='{self.email}', supportrepid={self.supportrepid})")