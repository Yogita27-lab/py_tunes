class Artist:
    def __init__ (self, name: str, artistid: int = None):
        self.artistid = artistid
        self.name = name

    def __repr__(self):
        return f"artists(id={self.artistid}, name={self.name})"