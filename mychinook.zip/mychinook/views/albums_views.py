from models.repos.albums_repos import AlbumRepo
from models.albums import Albums


def view_all_Albums():
    """Fetches and displays all Albums"""
    try:
        alr= AlbumRepo()
        alan = alr.get_all_albums()
        if not alan:
            print("No album are found.")
        else:
            for li in alan:
                print(f"Id: {li.albumid}, Name: {li.title}, Id: {li.artistid}")
    except Exception as e:
        print(f"An error occurred: {e}")
    

def view_albums():
    """Fetches and displays all albums."""
    try:
        alr= AlbumRepo()
        al_id=int(input("Enter Album ID: "))
        alan = alr.get_albums(al_id)
        if alan:
            print(f"ID: {alan.albumid}, Name: {alan.title}, ArtistID: {alan.artistid}.")
        else:
            print("Album not found")
    except Exception as e:
        print(f"An error occurred: {e}")

def create_albums():
    """Create a new album."""
    try:
        title=input("Enter Album Name: ")
        artistid=int(input("Enter Artist ID: "))
        model=Albums(title=title, artistid=artistid)
        alr=AlbumRepo()
        alr.create_albums(model)
        print("album created succesfully." )
    except Exception as e:
        print(F"An error occurred:{e}")

def update_albums():
    """update an existing albums."""
    try:
        albumid= int(input("Enter Album ID to update: "))
        title=(input("Enter new Album Name: "))
        artistid=int(input("Enter new Artist ID: "))
        model=Albums(albumid=albumid, title=title, artistid=artistid)
        alr=AlbumRepo()
        alr.update_albums(albumid, model)
        print("album are updated succesfully.")
    except Exception as e:
        print(F"An error occurred:{e}")

def delete_albums():
    """Delete an existing album."""
    try:
        albumid= int(input("Enter Album ID to delete: "))
        alr=AlbumRepo()
        alr.delete_albums(albumid)
        print("album are deleted.")
    except Exception as e:
        print(F"An error occurred:{e}")

def main():
    while True:
        print("\n======Albums Menu======")
        print("1. View all Albums")
        print("2. View Album by Id")
        print("3. Create Album")
        print("4. Update Album")
        print("5. Delete Album")
        print("0. Exit")

        choice=str(input("Enter Your Choice:"))

        if choice=='1':
            view_all_Albums()
        elif choice=='2':
            view_albums()
        elif choice=='3':
            create_albums()
        elif choice=='4':
            update_albums()
        elif choice=='5':
            delete_albums()
        elif choice=='0':
            print("Exit")
            break
        else:
            print("Invalid choice")

if __name__=="__main__":
   main()