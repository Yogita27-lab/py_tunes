from models.repos.customers_repos import CustomersRepo
from models.customers import Customers


def view_all_customers():
    """Fetches and displays all customers with all attributes."""
    try:
        cur = CustomersRepo()
        customers = cur.get_all_customers()
        if not customers:
            print("No customers found.")
        else:
            for c in customers:
                print(f"""
                Id: {c.customerid},
                FirstName: {c.firstname},
                LastName: {c.lastname},
                Company: {c.company},
                Address: {c.address},
                City: {c.city},
                State: {c.state},
                Country: {c.country},
                PostalCode: {c.postalcode},
                Phone: {c.phone},
                Fax: {c.fax},
                Email: {c.email},
                SupportRepId: {c.supportrepid}
                """)
    except Exception as e:
        print(f"An error occurred: {e}")


def view_customer():
    """Fetches and displays a single customer by ID with all attributes."""
    try:
        cur = CustomersRepo()
        cu_id = int(input("Enter customer ID: "))
        customer = cur.get_customers(cu_id)
        if customer:
            print(f"""
            Id: {customer.customerid},
            FirstName: {customer.firstname},
            LastName: {customer.lastname},
            Company: {customer.company},
            Address: {customer.address},
            City: {customer.city},
            State: {customer.state},
            Country: {customer.country},
            PostalCode: {customer.postalcode},
            Phone: {customer.phone},
            Fax: {customer.fax},
            Email: {customer.email},
            SupportRepId: {customer.supportrepid}
            """)
        else:
            print("Customer not found.")
    except Exception as e:
        print(f"An error occurred: {e}")


def add_customer():
    """Adds a new customer with all attributes."""
    try:
        cur = CustomersRepo()
        print("Enter new customer details:")
        first_name = input("First Name: ")
        last_name = input("Last Name: ")
        company = input("Company: ")
        address = input("Address: ")
        city = input("City: ")
        state = input("State: ")
        country = input("Country: ")
        postal_code = input("Postal Code: ")
        phone = input("Phone: ")
        fax = input("Fax: ")
        email = input("Email: ")
        support_rep_id = input("Support Rep ID: ")

        new_customer = Customers(
            firstname=first_name,
            lastname=last_name,
            company=company,
            address=address,
            city=city,
            state=state,
            country=country,
            postalcode=postal_code,
            phone=phone,
            fax=fax,
            email=email,
            supportrepid=support_rep_id
        )

        cur.add_customers(new_customer)
        print("✅ Customer added successfully.")

    except Exception as e:
        print(f"An error occurred: {e}")


def update_customers():
    """Updates customer details by ID."""
    try:
        cur = CustomersRepo()
        cu_id = int(input("Enter customer ID to update: "))
        customer = cur.get_customers(cu_id)

        if not customer:
            print("Customer not found.")
            return

        print("Leave blank to keep existing value.")

        first_name = input(f"First Name [{customer.firstname}]: ") or customer.firstname
        last_name = input(f"Last Name [{customer.lastname}]: ") or customer.lastname
        company = input(f"Company [{customer.company}]: ") or customer.company
        address = input(f"Address [{customer.address}]: ") or customer.address
        city = input(f"City [{customer.city}]: ") or customer.city
        state = input(f"State [{customer.state}]: ") or customer.state
        country = input(f"Country [{customer.country}]: ") or customer.country
        postal_code = input(f"Postal Code [{customer.postalcode}]: ") or customer.postalcode
        phone = input(f"Phone [{customer.phone}]: ") or customer.phone
        fax = input(f"Fax [{customer.fax}]: ") or customer.fax
        email = input(f"Email [{customer.email}]: ") or customer.email
        support_rep_id = input(f"Support Rep ID [{customer.supportrepid}]: ") or customer.supportrepid

        updated_customer = Customers(
            customerid=cu_id,
            firstname=first_name,
            lastname=last_name,
            company=company,
            address=address,
            city=city,
            state=state,
            country=country,
            postalcode=postal_code,
            phone=phone,
            fax=fax,
            email=email,
            supportrepid=support_rep_id
        )

        cur.update_customers(cu_id,updated_customer)
        print(" Customer updated successfully.")

    except Exception as e:
        print(f"An error occurred: {e}")


def delete_customer():
    """Deletes a customer by ID."""
    try:
        cur = CustomersRepo()
        cu_id = int(input("Enter customer ID to delete: "))
        cur.delete_customers(cu_id)
        print(" Customer deleted successfully.")
    except Exception as e:
        print(f"An error occurred: {e}")


def main():
    while True:
        print("====== CUSTOMER'S MENU ======")
        print("1. View all customers")
        print("2. View customer by Id")
        print("3. Add customer")
        print("4. Update customer")
        print("5. Delete customer")
        print("0. Exit")

        choice = str(input("Enter Your Choice: "))

        if choice == '1':
            view_all_customers()
        elif choice == '2':
            view_customer()
        elif choice == '3':
            add_customer()
        elif choice == '4':
            update_customers()
        elif choice == '5':
            delete_customer()
        elif choice == '0':
            print("Exit")
            break
        else:
            print("Invalid choice")


if __name__== "__main__":
    main()
