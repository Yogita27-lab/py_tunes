from models.repos.media_type_repos import MediaTypeRepos
from models.media_type import MediaType

def view_all_media_type():
    """Fetches and displays all media types."""
    try:
        mtr = MediaTypeRepos()
        gamt = mtr.get_all_media_types()
        if not gamt:
            print("No media types found.")
        else:
            for li in gamt:
                print(f"Id: {li.mediatypeid}, Name: {li.name}")
    except Exception as e:
        print(f"An error occurred: {e}")


def view_media_type():
    """Fetches and displays all media_types."""
    try:
        mtr= MediaTypeRepos()
        mt_id=int(input("Enter media type ID: "))
        gamt= mtr.get_media_type(mt_id)
        if gamt:
            print(f"ID: {gamt.mediatypeid}, Name: {gamt.name}.")
        else:
            print("media_type not found")
    except Exception as e:
        print(f"An error occurred: {e}")  


def create_media_type():
    """Create a new media_types."""
    try:
        name=input("Enter media_type Name: ")
        model=MediaType(name=name)
        mtr=MediaTypeRepos()
        mtr.create_media_type(model)
        print("media_types created succesfully." )
    except Exception as e:
        print(F"An error occurred:{e}")


def update_media_type():
    """update an existing media_type."""
    try:
        mediatypeid= int(input("Enter media_type ID to update: "))
        name=(input("Enter new media_type Name: "))
        model=MediaType(mediatypeid=mediatypeid, name=name)
        mtr=MediaTypeRepos()
        mtr.update_media_type(mediatypeid, model)
        print("media_type are updated succesfully.")
    except Exception as e:
        print(F"An error occurred:{e}") 


def delete_media_type():
    """Delete an existing media_type."""
    try:
        mediatpeid= int(input("Enter media_type ID to delete: "))
        mtr=MediaTypeRepos()
        mtr.delete_media_type(mediatpeid)
        print("media_type are deleted.")
    except Exception as e:
        print(F"An error occurred:{e}")  



def main():
    while True:
        print("\n======Media_type's MENU ======")
        print("media_type Menu")
        print("1. View all media_type")
        print("2. View media_type by Id")
        print("3. Create media_type")
        print("4. Update media_type")
        print("5. Delete media_type")
        print("0. Exit")

        choice=str(input("Enter Your Choice:"))

        if choice=='1':
            view_all_media_type()
        elif choice=='2':
            view_media_type()
        elif choice=='3':
            create_media_type()
        elif choice=='4':
            update_media_type()
        elif choice=='5':
            delete_media_type()
        elif choice=='0':
            print("Exit")
            break
        else:
            print("Invalid choice")
                           

if __name__=="__main__":
    main()