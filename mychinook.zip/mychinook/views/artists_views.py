from models.repos.artists_repos import ArtistRepo
from models.artists import Artist
def view_all_artist():
    """Fetches and displays all artists."""
    try:
        atr= ArtistRepo()
        atan = atr.get_all_artists()
        if not atan:
            print("No artists are found.")
        else:
            for li in atan:
                print(f" Name: {li.name}")
    except Exception as e:
        print(f"An error occurred: {e}")


def view_artist():
    """Fetches and displays all artists."""
    try:
        atr = ArtistRepo()
        atan= atr.get_all_artists()
        if not atan:
            print("No artists are found.")
        else:
            for li in atan:
                print(f"Id: {li.artistid}, Name: {li.name}")
    except Exception as e:
        print(f"An error occurred: {e}") 

def create_artists():
    """Create a new artists."""
    try:
        name=input("Enter artist Name: ")
        model=Artist(name=name)
        atr=ArtistRepo()
        atr.create_artists(model)
        print("artist are created succesfully." )
    except Exception as e:
        print(F"An error occurred:{e}")


def update_artists():
    """update an existing artists."""
    try:
        artistid= int(input("Enter artist ID to update: "))
        name=(input("Enter new artists Name: "))
        model=Artist(artistid=artistid, name=name)
        atr=ArtistRepo()
        atr.update_artists(artistid, model)
        print("artists are updated succesfully.")
    except Exception as e:
        print(F"An error occurred:{e}") 

def delete_artists():
    """Delete an existing artists."""
    try:
        artistid= int(input("Enter artistID to delete: "))
        atr=ArtistRepo()
        atr.delete_artists(artistid)
        print("artists are deleted.")
    except Exception as e:
        print(F"An error occurred:{e}")  

       

def view_artist_with_albums():
    """Fetches and displays all artist with albums."""
    try:
        atr =  ArtistRepo()
        data = atr.get_artist_with_albums()
        if not data:
            print("No artists-albums are found.")
        else:
            for name, name in data:
                print(f"Artist: {name} | Album: {name}")
    except Exception as e:
        print(f"An error occurred: {e}")
        


def main():
    while True:
     print("\n======ARTISTS's MENU======")
     print("choose an option:")
     print("1. view artists")
     print("2.view artist with albums")
     print("3. view with ID artists")
     print("4. create artists")
     print("5. update artists")
     print("6. delete artists")

     choice=input("entre your choice: ")
     if choice == "1":
        view_all_artist()
     elif choice == "2":
        view_artist_with_albums()
     elif choice == "3":
        view_artist()
     elif choice == "4":
        create_artists()
     elif choice == "5":
        update_artists()
     elif choice == "6":
        delete_artists()
     elif choice == "0":
        print('Exit')
        break            
     else:
        print("invalid choice")
        

if __name__=="__main__": 
    main()