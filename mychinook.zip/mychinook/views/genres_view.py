from models import genres
from models.repos.genres_repo import GenresRepo
from models.genres import Genres
def view_all_genre():
    """Fetches and displays all albums."""
    try:
        gnr = GenresRepo()
        gagn = gnr.get_all_genres()
        if not gagn:
            print("No genre found.")
        else:
            for li in gagn:
                print(f"Id: {li.genreid}, Name: {li.name},")
    except Exception as e:
        print(f"An error occurred: {e}")
def view_genres():
    """Fetches and displays all genres."""
    try:
        gnr = GenresRepo()
        gagn = gnr.get_all_genres()
        if not gagn:
            print("No genres found.")
        else:
            for li in gagn:
                print(f"Id: {li.genreid}, Name: {li.name}")
    except Exception as e:
        print(f"An error occurred: {e}")

def create_genres():
    """create new genres."""
    try:
        name = input("Entre the genre name: ")
        genreid= int (input("Entre genre ID: "))
        model = Genres(name=name , genreid=genreid)
        gnr =  GenresRepo()
        gnr.create_genres(model)
        print("genre created succesfully.")
        
    except Exception as e:
        print(f"An error occurred: {e}")

def update_genres():
    """update an existing albums."""
    try:
        name= int(input("Entre genre: "))
        genreid=int(input("Entre the new artist ID: "))
        model = genres(genreid=genreid ,name=name)
        gnr =  GenresRepo()
        gnr.update_genres(genreid,model)
        print(" genre updated succesfully.")
    except Exception as e:
        print(f"An error occurred: {e}")

def delete_genres():
    """Delete an existing genres."""
    try:
        genreid= int(input("Enter genre ID to delete: "))
        gnr=GenresRepo()
        gnr.delete_genres(genreid)
        print("genre are deleted.")
    except Exception as e:
        print(F"An error occurred:{e}")
 
def main():
    while True:
        print("\n====== GENRES MENU ======")
        print("1. View all genre")
        print("2. View genre by Id")
        print("3. Create genre")
        print("4. Update genre ")
        print("5. Delete genre")
        print("0. Exit")

        choice=str(input("Enter Your Choice:"))

        if choice=='1':
            view_all_genre()
        elif choice=='2':
            view_genres()
        elif choice=='3':
            create_genres()
        elif choice=='4':
            update_genres()
        elif choice=='5':
            delete_genres()
        elif choice=='0':
            print("Exit")
            break
        else:
            print("Invalid choice")

if __name__=="__main__":
    main()