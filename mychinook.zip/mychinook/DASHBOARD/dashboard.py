from views.albums_views import main as albums_menu
from views.artists_views import main as artists_menu
from views.customers_views import main as customers_menu
from views.genres_view import main as genres_menu
from views.media_type_view import main as media_types_menu


def dashboard():
    while True:
        print("\n======= DASHBOARD MENU =======")
        print("1. Albums Menu")
        print("2. Artists Menu")
        print("3. Customers Menu")
        print("4. Genres Menu")
        print("5. Media Types Menu")
        print("0. Exit Program")

        choice = input("Enter your choice: ")

        if choice == '1':
            albums_menu()
        elif choice == '2':
            artists_menu()
        elif choice == '3':
            customers_menu()
        elif choice == '4':
            genres_menu()
        elif choice == '5':
            media_types_menu()
        elif choice == '0':
            print("Exiting program...")
            break
        else:
            print("Invalid choice. Please try again.")


if __name__ == "__main__":
    dashboard()